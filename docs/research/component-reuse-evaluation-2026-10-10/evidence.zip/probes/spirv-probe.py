import json,time,subprocess,hashlib,shutil
from pathlib import Path
base=Path('/Users/jneerdael/Scripts/Projectm-TV/.worktrees/predictor-memory-repair/build/preset-corpus/source-shape-flash-size-2000-2026-10-10')
out=Path(__file__).parent/'spirv';out.mkdir(exist_ok=True)
selection=json.loads((base/'sample-selection.json').read_text())['presets'][:32];rows=[]
validator='/opt/homebrew/Cellar/glslang/16.6.0/bin/glslang'
for i,c in enumerate(selection):
 proof=json.loads((base/'compatibility'/Path(c['relative_path']).with_suffix('.json')).read_text())
 for stage,r in proof['reports'].items():
  if r['translation']['status']!='translated':continue
  root=out/(str(i)+'-'+stage);root.mkdir(exist_ok=True);exact=r['translation']['glsl'];(root/'exact.frag').write_text(exact);(root/'inspection.frag').write_text(exact.replace('#version 300 es','#version 310 es',1));start=time.perf_counter()
  a=subprocess.run([validator,'-i','-S','frag',str(root/'exact.frag')],capture_output=True,text=True,timeout=20);(root/'exact-ast.txt').write_text(a.stdout+a.stderr)
  b=subprocess.run([validator,'-G','--auto-map-locations','--auto-map-bindings','-S','frag',str(root/'inspection.frag'),'-o',str(root/'code.spv')],capture_output=True,text=True,timeout=20);(root/'compile.log').write_text(b.stdout+b.stderr)
  row={'preset':c,'stage':stage,'exact_ast_accepted':a.returncode==0,'inspection_spirv_accepted':b.returncode==0,'seconds':time.perf_counter()-start,'exact_glsl_sha256':hashlib.sha256(exact.encode()).hexdigest(),'native_driver_parity':False}
  if b.returncode==0:
   z=subprocess.run([shutil.which('spirv-opt'),'--merge-return','--inline-entry-points-exhaustive','--eliminate-dead-functions','--ssa-rewrite','--eliminate-dead-code-aggressive',str(root/'code.spv'),'-o',str(root/'normalized.spv')],capture_output=True,text=True,timeout=20);(root/'optimize.log').write_text(z.stdout+z.stderr);row['optimizer_accepted']=z.returncode==0
   for file in ('code','normalized'):
    if (root/(file+'.spv')).exists():subprocess.run([shutil.which('spirv-dis'),str(root/(file+'.spv')),'-o',str(root/(file+'.spvasm'))],check=True,capture_output=True)
  rows.append(row)
(out/'results.json').write_text(json.dumps(rows,indent=2));print(json.dumps({'presets':32,'sections':len(rows),'exact_ast':sum(r['exact_ast_accepted'] for r in rows),'inspection_spirv':sum(r['inspection_spirv_accepted'] for r in rows),'optimized':sum(r.get('optimizer_accepted',False) for r in rows),'total_compile_seconds':sum(r['seconds'] for r in rows)}))
