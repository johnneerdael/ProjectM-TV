import {readFileSync,writeFileSync} from 'node:fs';
import {compileMilkdropPresetSource} from '../stims/packages/milkdrop-toolchain/src/compiler.ts';
import {analyzePresetDataflow} from '../stims/packages/milkdrop-toolchain/src/preset-dataflow.ts';
const cases=JSON.parse(readFileSync(new URL('./sample32.json',import.meta.url),'utf8'));
const rows=cases.map((c:any)=>{const start=performance.now();try{const r=compileMilkdropPresetSource(readFileSync(c.path,'utf8'),{id:c.relative_path});const d=analyzePresetDataflow(r.ir);return {preset:c,ms:performance.now()-start,diagnostics:r.diagnostics,variables:Object.fromEntries(d.variables),drawn:{shapes:d.drawnAudio.shapes,waves:d.drawnAudio.waves,perPixel:d.drawnAudio.perPixel},compatibility:r.ir.compatibility,post:r.ir.post};}catch(e){return {preset:c,ms:performance.now()-start,error:String(e)}}});
writeFileSync(new URL('./stims-corpus.json',import.meta.url),JSON.stringify(rows,null,2));console.log(JSON.stringify({cases:rows.length,exceptions:rows.filter(x=>x.error).length,compileErrors:rows.filter(x=>x.diagnostics?.some((d:any)=>d.severity==='error')).length,totalMs:rows.reduce((s,x)=>s+x.ms,0)}));
