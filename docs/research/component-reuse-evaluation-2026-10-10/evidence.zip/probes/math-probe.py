import json,time,sympy as sp,z3
rows=[]
def record(name,f):
 start=time.perf_counter();value=f();rows.append({'case':name,'result':str(value),'ms':(time.perf_counter()-start)*1000})
x=sp.Symbol('bass',real=True);t=sp.Symbol('time',real=True)
record('trig_cancellation_derivative',lambda:sp.trigsimp(sp.diff(sp.sin(x)**2+sp.cos(x)**2,x)))
record('rational_shape_area_derivative',lambda:sp.diff(sp.Rational(1,2)*(sp.Rational(1,5)+x/sp.Integer(10))**2,x))
q,b=z3.Reals('q bass')
def proof(assumptions,conclusion):
 s=z3.Solver();s.set(timeout=1000);s.add(*assumptions,z3.Not(conclusion));return s.check()
record('bounded_persistent_state_induction',lambda:proof([q>=0,q<=1,b>=0,b<=2],z3.And(z3.If(q+b/100>1,1,q+b/100)>=0,z3.If(q+b/100>1,1,q+b/100)<=1)))
record('unbounded_state_mutation_counterexample',lambda:proof([q>=0,q<=1,b>=0,b<=2],q+b/100<=1))
record('correlated_zero_divisor',lambda:proof([b>=0,b<=2],b-b==0))
a=z3.FP('a',z3.Float32());zero=z3.FPVal(0,z3.Float32());one=z3.FPVal(1,z3.Float32());v=z3.If(z3.fpLT(a,zero),zero,z3.If(z3.fpGT(a,one),one,a))
record('float32_finite_clamp_range',lambda:proof([z3.Not(z3.fpIsNaN(a)),z3.Not(z3.fpIsInf(a))],z3.And(z3.fpGEQ(v,zero),z3.fpLEQ(v,one))))
print(json.dumps({'sympy':sp.__version__,'z3':z3.get_version_string(),'cases':rows},indent=2));open(__file__.replace('math-probe.py','math-results.json'),'w').write(json.dumps({'sympy':sp.__version__,'z3':z3.get_version_string(),'cases':rows},indent=2))
