import {readFileSync,writeFileSync} from 'node:fs';
import {compileMilkdropPresetSource} from '../stims/packages/milkdrop-toolchain/src/compiler.ts';
import {analyzePresetDataflow} from '../stims/packages/milkdrop-toolchain/src/preset-dataflow.ts';
import {evaluateMilkdropExpression,parseMilkdropExpression} from '../stims/packages/milkdrop-toolchain/src/expression.ts';
const cases=JSON.parse(readFileSync(new URL('./controls.json',import.meta.url),'utf8'));
const rows=cases.map((c:any)=>{const start=performance.now();const r=compileMilkdropPresetSource(c.source,{id:c.name});const d=analyzePresetDataflow(r.ir);return {name:c.name,ms:performance.now()-start,diagnostics:r.diagnostics,variables:Object.fromEntries(d.variables),drawn:{shapes:d.drawnAudio.shapes,waves:d.drawnAudio.waves,perPixel:d.drawnAudio.perPixel},shader:r.ir.shaders};});
writeFileSync(new URL('./stims-controls.json',import.meta.url),JSON.stringify(rows,null,2));
const sqrt=parseMilkdropExpression('sqrt(-1)',1);console.log(JSON.stringify({count:rows.length,sqrtNegative:evaluateMilkdropExpression(sqrt.value!,{})}));
