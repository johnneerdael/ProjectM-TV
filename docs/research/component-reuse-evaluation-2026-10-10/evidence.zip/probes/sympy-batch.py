import json,time,signal,sympy as sp
from pathlib import Path
class Timeout(Exception):pass
def alarm(a,b):raise Timeout()
signal.signal(signal.SIGALRM,alarm)
p=Path(__file__).parent;cases=json.loads((p/'pure-center-candidates.json').read_text());rows=[]
for c in cases:
 start=time.perf_counter();r={k:v for k,v in c.items() if k!='program'}
 try:
  signal.setitimer(signal.ITIMER_REAL,1);nodes=c['program']['nodes'];memo={}
  def visit(i):
   if i in memo:return memo[i]
   n=nodes[i];args=[visit(k) for k in n['args']];op=n['op']
   if op=='input':v=sp.Symbol(n['detail']['name'],real=True)
   elif op=='constant':v=sp.Rational(n['detail']['value'])
   elif op=='add':v=args[0]+args[1]
   elif op=='subtract':v=args[0]-args[1]
   elif op=='multiply':v=args[0]*args[1]
   elif op=='sin':v=sp.sin(args[0])
   elif op=='cos':v=sp.cos(args[0])
   else:raise ValueError(op)
   memo[i]=v;return v
  f=visit(c['program']['root']);results=[]
  for name in c['bands']:
   derivative=sp.diff(f,sp.Symbol(name,real=True));constant=derivative if not derivative.free_symbols else None
   results.append({'band':name,'constant_nominal_derivative':str(constant) if constant is not None else None,'derivative':str(derivative),'existing_unknown':name in c['unknown_bands']})
  r['derivatives']=results;r['status']='derived'
 except Exception as e:r.update(status='timeout' if isinstance(e,Timeout) else 'error',error=str(e))
 finally:signal.setitimer(signal.ITIMER_REAL,0)
 r['seconds']=time.perf_counter()-start;rows.append(r)
(p/'sympy-batch-results.json').write_text(json.dumps(rows,indent=2));new=[r for r in rows if any(d['constant_nominal_derivative'] is not None and d['existing_unknown'] for d in r.get('derivatives',[]))];summary={'candidate_axes':len(rows),'derived':sum(r['status']=='derived' for r in rows),'timeout':sum(r['status']=='timeout' for r in rows),'seconds':sum(r['seconds'] for r in rows),'new_constant_derivative_axes':len(new),'new_constant_derivative_presets':len({r['preset']['relative_path'] for r in new}),'note':'derivative generation is not interval bounding or native parity'};(p/'sympy-batch-summary.json').write_text(json.dumps(summary,indent=2));print(summary)
