import json,time,sympy as sp
from pathlib import Path
def derivative(program,variable):
 if not program.get('complete') or not program.get('resources_resolved'):raise ValueError('incomplete exported program')
 nodes=program['nodes'];memo={};active=set()
 def visit(index):
  if index in memo:return memo[index]
  if index in active or len(memo)+len(active)>512:raise ValueError('graph cycle/budget')
  active.add(index);n=nodes[index];op=n['op'];detail=n['detail']
  if n['dtype']!='float' or detail.get('numeric_domain') or op in {'cast','narrow','sequence','sample'}:raise ValueError('non-real or effectful node excluded')
  args=[visit(i) for i in n['args']]
  if op=='input':value=sp.Symbol(detail['name'],real=True)
  elif op=='constant':value=sp.Rational(detail['value'])
  elif op=='add':value=args[0]+args[1]
  elif op=='subtract':value=args[0]-args[1]
  elif op=='multiply':value=args[0]*args[1]
  elif op=='sin':value=sp.sin(args[0])
  elif op=='cos':value=sp.cos(args[0])
  else:raise ValueError('unsupported node:'+op)
  active.remove(index);memo[index]=value;return value
 expression=visit(program['root']);return {'expression':str(expression),'derivative':str(sp.trigsimp(sp.diff(expression,sp.Symbol(variable,real=True)))),'mode':'nominal real formula only','native_numeric_parity':False}
p=Path(__file__).parent;program=json.loads((p/'predictor-expression.json').read_text());start=time.perf_counter();result=derivative(program,'bass');result['ms']=(time.perf_counter()-start)*1000
for forbidden in ('cast','narrow','sample','sequence'):
 negative={'complete':True,'resources_resolved':True,'root':0,'nodes':[{'op':forbidden,'dtype':'float','args':[],'detail':{}}]}
 try:derivative(negative,'bass');raise AssertionError('unsafe node accepted')
 except ValueError:pass
result['negative_controls']=4;print(json.dumps(result,indent=2));(p/'sympy-graph-result.json').write_text(json.dumps(result,indent=2))
