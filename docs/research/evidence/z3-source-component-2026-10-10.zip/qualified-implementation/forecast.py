"""Compose source-only forecasts under explicitly declared state and inputs.

This executes a mathematical source model; it does not claim validated native
appearance accuracy. Inputs are parser output, source-generated audio/assets,
initial state and optional source random lifecycle. No reference frames enter.
"""
import hashlib
import copy
import json
from pathlib import Path
import subprocess
import tempfile
import numpy as np
from builtin_wave import source_builtin_wave
from custom_wave import source_custom_waves, DEFAULT_SMOOTHING, FMA_SMOOTHING
from descriptors import DescriptorStream
from pipeline_fields import SourcePipeline
from scene_draw import draw_source_scene
from scene_equations import execute_scene
from scene_warp import warp_fields
from shader_random import bind_random_uniforms
from shader_uniforms import source_uniforms
from spatial import sample2d
from sampling_policy import texture_settings
from geometry_features import scene_geometry_features
from materials import material_input_identity
from source_features import forecast_feature_record, SIMULATED
from engine_profiles import (CORE_2315_ENGINE,CORE_2316_ENGINE,CORE_2317_ENGINE,CORE_2321_ENGINE,CORE_2322_ENGINE,CORE_2325_ENGINE,CORE_2327_ENGINE,CORE_2329_ENGINE,CORE_2331_ENGINE,CORE_2334_ENGINE,CORE_2331_DISPLAY,CORE_2331_LEGACY_WARP,LEGACY_WARP,CORE_2327_ZOOM,CORE_2315_SHAPE,CORE_2315_BLUR,CORE_2315_ZOOM,
    CORE_2315_DISPLAY,CORE_2315_WAVE,LEGACY_BLUR,LEGACY_ZOOM,LEGACY_DISPLAY,LEGACY_WAVE,matches,math_matches,select_policy)
from shape_sampling import LEGACY as LEGACY_SHAPE_POLICY,CORE_238 as CORE_238_SHAPE_POLICY,native_blur_level,shape_sampling_modes

# Patched projectM-eval TreeFunctions.c initializes MT19937 once per thread.
# This policy covers a cold evaluator thread, not a later preset switch.
PRODUCTION_EQUATION_SEED = 0x4141f00d
PRODUCTION_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.4-cold-thread-v1'
PRODUCTION_EQUATION_ENGINE = {
    'commit': 'e0b0a967f0ffd7d332106c366668ed271718472b',
    'patches_sha256': 'd21d4e3d9725178c000fd6f7ea5cd331389fb1100b70fce51341ece65d3fd818',
}
CORE_235_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.5-cold-thread-v1'
CORE_235_EQUATION_ENGINE = {
    'commit': 'e0b0a967f0ffd7d332106c366668ed271718472b',
    'patches_sha256': 'd73c955a26380a502516e6ba3a18baf753851244de4de2e5a3083930766a539a',
}
CORE_237_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.7-cold-thread-v1'
CORE_237_EQUATION_ENGINE = {
    'commit': 'e0b0a967f0ffd7d332106c366668ed271718472b',
    'patches_sha256': 'd70f5b5ec3f3c0b4da764cb824153f142b88e17e27c2e9e71d2b481c19998c7d',
}
CORE_2310_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.10-cold-thread-v1'
CORE_2310_EQUATION_ENGINE = {
    'commit': 'e0b0a967f0ffd7d332106c366668ed271718472b',
    'patches_sha256': '545ca48adad787f963f9b29c1fc4fd7e8a71fb910f586c8747f96a075d130ddf',
}
CORE_2315_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.15-cold-thread-v1'
CORE_2316_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.16-cold-thread-v1'
CORE_2317_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.17-cold-thread-v1'
CORE_2321_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.21-cold-thread-v1'
CORE_2322_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.22-cold-thread-v1'
CORE_2325_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.25-cold-thread-v1'
CORE_2327_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.27-cold-thread-v1'
CORE_2329_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.29-cold-thread-v1'
CORE_2334_EQUATION_RNG_POLICY = "projectmtv-core-2.3.34-cold-thread-v1"
CORE_2331_EQUATION_RNG_POLICY = 'projectmtv-core-2.3.31-cold-thread-v1'
# Patch0044 changes literal formatting; equation RNG and sampler ownership
# retain the verified43-patch contracts. Keep44 as a distinct source identity.
# Keep historical 2.3.4 identity. Patch 0042 adds feedback and shader random caching;
# the equation RNG's cold-thread seed remains unchanged.
PRODUCTION_EQUATION_ENGINES = {
    PRODUCTION_EQUATION_RNG_POLICY: PRODUCTION_EQUATION_ENGINE,
    CORE_235_EQUATION_RNG_POLICY: CORE_235_EQUATION_ENGINE,
    CORE_237_EQUATION_RNG_POLICY: CORE_237_EQUATION_ENGINE,
    CORE_2310_EQUATION_RNG_POLICY: CORE_2310_EQUATION_ENGINE,
    CORE_2315_EQUATION_RNG_POLICY: CORE_2315_ENGINE,
    CORE_2316_EQUATION_RNG_POLICY: CORE_2316_ENGINE,
    CORE_2317_EQUATION_RNG_POLICY: CORE_2317_ENGINE,
    CORE_2321_EQUATION_RNG_POLICY: CORE_2321_ENGINE,
    CORE_2322_EQUATION_RNG_POLICY: CORE_2322_ENGINE,
    CORE_2325_EQUATION_RNG_POLICY: CORE_2325_ENGINE,
    CORE_2327_EQUATION_RNG_POLICY: CORE_2327_ENGINE,
    CORE_2329_EQUATION_RNG_POLICY: CORE_2329_ENGINE,
    CORE_2331_EQUATION_RNG_POLICY: CORE_2331_ENGINE,
    CORE_2334_EQUATION_RNG_POLICY: CORE_2334_ENGINE,
}


def source_centre_policies(engine,domain):
    from composite_mesh import LEGACY_CENTRES,CORE_2322_CENTRES
    from primitives import LEGACY_SHAPE_CENTRES,CORE_2322_SHAPE_CENTRES
    corrected=matches(engine,CORE_2322_ENGINE) or (matches(engine,CORE_2325_ENGINE) or (matches(engine,CORE_2327_ENGINE) or (matches(engine,CORE_2329_ENGINE) or math_matches(engine,CORE_2331_ENGINE))))
    composite=domain.get('composite_centre_policy',CORE_2322_CENTRES if corrected else LEGACY_CENTRES)
    shape=domain.get('shape_centre_policy',CORE_2322_SHAPE_CENTRES if corrected else LEGACY_SHAPE_CENTRES)
    if composite not in (LEGACY_CENTRES,CORE_2322_CENTRES) or shape not in (LEGACY_SHAPE_CENTRES,CORE_2322_SHAPE_CENTRES):
        raise ValueError('unknown centre policy')
    if not corrected and (composite==CORE_2322_CENTRES or shape==CORE_2322_SHAPE_CENTRES):
        raise ValueError('corrected centre policy engine identity mismatch')
    return composite,shape


def source_builtin_viewport_policy(engine,domain):
    from quad_lines import PROFILE,LEGACY_VIEWPORT,RETAINED_CLIP_VIEWPORT
    bits=domain.get('triangle_subpixel_bits')
    qualified=((matches(engine,CORE_2325_ENGINE) or (matches(engine,CORE_2327_ENGINE) or (matches(engine,CORE_2329_ENGINE) or math_matches(engine,CORE_2331_ENGINE)))) and domain.get('profile')=='gles300' and
               domain.get('line_rendering_profile')==PROFILE and type(bits) is int and 4<=bits<=16)
    selected=domain.get('builtin_wave_viewport_policy',RETAINED_CLIP_VIEWPORT if qualified else LEGACY_VIEWPORT)
    if selected not in (LEGACY_VIEWPORT,RETAINED_CLIP_VIEWPORT):
        raise ValueError('unknown builtin wave viewport policy')
    if selected==RETAINED_CLIP_VIEWPORT and not qualified:
        raise ValueError('retained builtin viewport requires exact engine, GLES quad lines and explicit grid')
    return selected


def source_main_binding_policy(engine: dict, requested: str | None) -> str:
    """Use the verified engine's unit-zero contract unless explicitly overridden.

    Unknown sources retain the historical default. An explicit historical policy
    remains available for labeled diagnostics, not current-AAR certification.
    """
    if requested is not None:
        if requested not in {'legacy-sorted-v1','projectmtv-core-2.2.6-v1'}:
            raise ValueError('unsupported main binding policy')
        return requested
    if any(all(engine.get(key)==value for key,value in expected.items())
           for expected in PRODUCTION_EQUATION_ENGINES.values()):
        return 'projectmtv-core-2.2.6-v1'
    return 'legacy-sorted-v1'


def source_shape_sampler_policy(engine: dict, requested: str | None) -> str:
    if matches(engine):
        if requested is None or requested == CORE_2315_SHAPE:return CORE_2315_SHAPE
    elif requested == CORE_2315_SHAPE:
        raise ValueError('shape sampler engine identity mismatch')
    verified=any(all(engine.get(key)==value for key,value in expected.items())
                 for expected in (CORE_237_EQUATION_ENGINE,CORE_2310_EQUATION_ENGINE,CORE_2315_ENGINE,CORE_2316_ENGINE,CORE_2317_ENGINE))
    policy=requested if requested is not None else CORE_238_SHAPE_POLICY if verified else LEGACY_SHAPE_POLICY
    if policy not in {LEGACY_SHAPE_POLICY,CORE_238_SHAPE_POLICY}:
        raise ValueError('unsupported shape sampler policy')
    if policy==CORE_238_SHAPE_POLICY and not verified:
        raise ValueError('shape sampler engine identity mismatch')
    return policy


DETAIL_POLICY='projectmtv-authored-native-detail-v1'


def forecast_detail_context(engine,domain):
    """Condition source math on a declared successful native detail allocation."""
    policy=domain.get('authored_canvas_policy')
    if policy is None:return None
    if policy!=DETAIL_POLICY:raise ValueError('unknown authored canvas policy')
    if not any(math_matches(engine,target) for target in (CORE_2325_ENGINE,CORE_2327_ENGINE,CORE_2329_ENGINE,CORE_2331_ENGINE)):
        raise ValueError('authored detail engine identity mismatch')
    if domain.get('profile')!='gles300' or domain.get('quantize') is not True:
        raise ValueError('authored detail requires GLES300 normalized storage')
    if domain.get('feedback_detail_resource_status')!='allocated':
        raise ValueError('authored detail allocation is not declared successful')
    from authored_canvas import detail_configuration
    context=detail_configuration(native_size=(domain['width'],domain['height']),
        physical_size=domain.get('physical_size'),trails_level=domain.get('native_trails_level'))
    if context['authored_size'] is None:raise ValueError('authored detail has no active integer canvas')
    if domain.get('feedback_detail_alpha',context['alpha'])!=context['alpha']:
        raise ValueError('declared detail gain contradicts JNI trails setting')
    if domain.get('line_rendering_profile')!='projectmtv-gles-quad-lines-v1':
        raise ValueError('authored detail requires explicit native quad-line profile')
    context['declared_resource_status']='allocated'
    return context


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def model_file_hashes():
    return {path.name:hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(Path(__file__).parent.glob('*.py'))
            if not path.name.startswith('test_')}


_MODEL_IMPORT_HASHES=model_file_hashes()


from scene_equations import source_settings


def read_source(path: Path, *, reader: Path, timeout=30) -> dict:
    path=Path(path);reader=Path(reader).resolve()
    raw=path.read_bytes()
    reader_bytes=reader.read_bytes()
    binary_sha=hashlib.sha256(reader_bytes).hexdigest()
    # Execute the exact bytes hashed here, even if the workspace file changes.
    with tempfile.TemporaryDirectory(prefix='milk-forecast-source-') as directory:
        frozen=Path(directory)/path.name
        frozen.write_bytes(raw)
        executable_dir=Path(directory)/'adapter';executable_dir.mkdir()
        executable=executable_dir/'reader';executable.write_bytes(reader_bytes);executable.chmod(0o700)
        process=subprocess.run([str(executable),str(frozen)],capture_output=True,text=True,timeout=timeout)
    if process.returncode:
        raise ValueError('source parser execution failed: '+process.stderr.strip())
    result=json.loads(process.stdout)
    engine=result.get('parser_inputs',{}).get('engine',{})
    if matches(engine,CORE_2321_ENGINE) or matches(engine,CORE_2322_ENGINE) or (matches(engine,CORE_2325_ENGINE) or (matches(engine,CORE_2327_ENGINE) or (matches(engine,CORE_2329_ENGINE) or math_matches(engine,CORE_2331_ENGINE)))):
        result['parser_inputs']['setting_lookup_policy']='native-case-insensitive-v1'
        result['values']=source_settings(result)
    result.update(preset=path.name,preset_sha256=hashlib.sha256(raw).hexdigest(),reader_sha256=binary_sha)
    return result


def display_visibility(display):
    """Exact encoded RGB8 facts; nonzero does not imply perceptual visibility."""
    values=np.asarray(display,dtype=np.float32)
    if values.ndim!=3 or values.shape[-1]!=4 or not np.all(np.isfinite(values)):
        raise ValueError('finite RGBA display field required for visibility facts')
    rgb8=np.rint(np.clip(values[...,:3],0,1)*np.float32(255)).astype(np.uint8)
    count=int(np.count_nonzero(np.any(rgb8!=0,axis=-1)))
    return dict(basis='source-predicted-encoded-rgb8',peak_rgb8=int(rgb8.max()),
                nonzero_rgb8_pixels=count,total_pixels=int(rgb8.shape[0]*rgb8.shape[1]),
                uniformly_black_rgb8=count==0,
                limitation='Nonzero encoded samples do not prove human-visible or trackable motion')


def forecast_source(source: dict, *, audio: dict, binaries: Path, domain: dict,
                    compatibility: dict, random_inputs=None, noise_bank=None, materials=None,
                    retain_surfaces=True, on_frame=None, motion_uv_sampler=None) -> dict:
    model_hashes=model_file_hashes()
    if model_hashes!=_MODEL_IMPORT_HASHES:
        raise ValueError('forecast model files changed since import; start a fresh process')
    source=copy.deepcopy(source);audio=copy.deepcopy(audio);domain=copy.deepcopy(domain)
    if 'values' in source:
        source['values']=source_settings(source)
    compatibility=copy.deepcopy(compatibility)
    random_inputs=copy.deepcopy(random_inputs)
    noise_bank,materials=copy.deepcopy((noise_bank,materials))
    descriptors=DescriptorStream(warmup_frames=domain.get('descriptor_warmup_frames',0),
                                 settings=domain.get('descriptor_settings'),
                                 motion_window_policy=domain.get('motion_window_policy','legacy-supported-subset-v1'))
    required = {'width','height','mesh_x','mesh_y','profile','initial_rgba',
                'hue_offsets','equation_seed','blur_levels','quantize'}
    if not required.issubset(domain):
        raise ValueError('forecast domain missing explicit settings: ' + ', '.join(sorted(required-set(domain))))
    if domain.get('numeric_profile')=='apple-m4pro-gl41-nan-mesh-v1' and domain['profile']!='glsl330':
        raise ValueError('Apple numeric profile requires glsl330 shader backend')
    if type(domain['quantize']) is not bool or type(retain_surfaces) is not bool:
        raise ValueError('explicit boolean quantization/retention settings required')
    if domain.get('authored_canvas_policy') is None and domain.get('feedback_detail_alpha',-1.0)!=-1.0:
        raise ValueError('feedback detail alpha passes are not implemented in source forecasts')
    if type(domain['equation_seed']) is not int or not 0<=domain['equation_seed']<2**32:
        raise ValueError('explicit uint32 equation seed required')
    rng_policy = domain.get('equation_rng_policy', 'declared-seed-v1')
    if rng_policy != 'declared-seed-v1' and rng_policy not in PRODUCTION_EQUATION_ENGINES:
        raise ValueError('unknown equation RNG policy: ' + str(rng_policy))
    production_engine = PRODUCTION_EQUATION_ENGINES.get(rng_policy)
    if production_engine is not None and domain['equation_seed'] != PRODUCTION_EQUATION_SEED:
        raise ValueError('production equation RNG seed must be 0x4141f00d')
    engine = source.get('parser_inputs', {}).get('engine', {})
    main_binding_policy=source_main_binding_policy(engine,domain.get('main_binding_policy'))
    shape_sampler_policy=source_shape_sampler_policy(engine,domain.get('shape_sampler_policy'))
    blur_range_policy=select_policy(engine,domain.get('blur_range_policy'),current=CORE_2315_BLUR,legacy=LEGACY_BLUR)
    if (matches(engine,CORE_2327_ENGINE) or (matches(engine,CORE_2329_ENGINE) or math_matches(engine,CORE_2331_ENGINE))) and domain.get('warp_zoom_policy',CORE_2327_ZOOM)==CORE_2327_ZOOM:
        warp_zoom_policy=CORE_2327_ZOOM
    else:
        warp_zoom_policy=select_policy(engine,domain.get('warp_zoom_policy'),current=CORE_2315_ZOOM,legacy=LEGACY_ZOOM)
    requested_display=domain.get('legacy_control_policy')
    if math_matches(engine,CORE_2331_ENGINE) and requested_display in (None,CORE_2331_DISPLAY):
        legacy_control_policy=CORE_2331_DISPLAY
    else:
        legacy_control_policy=select_policy(engine,requested_display,current=CORE_2315_DISPLAY,legacy=LEGACY_DISPLAY)
    wave_control_policy=select_policy(engine,domain.get('wave_control_policy'),current=CORE_2315_WAVE,legacy=LEGACY_WAVE)
    if production_engine is not None:
        if any(engine.get(key) != value for key, value in production_engine.items()):
            raise ValueError('production equation RNG engine identity mismatch')
    if any(type(domain[k]) is not int or domain[k]<=0 for k in ['width','height']):
        raise ValueError('positive integer forecast viewport required')
    detail_context=forecast_detail_context(engine,domain)
    for version, expected in [('2.3.5',CORE_235_EQUATION_ENGINE),('2.3.7',CORE_237_EQUATION_ENGINE),
                              ('2.3.10',CORE_2310_EQUATION_ENGINE),('2.3.15',CORE_2315_ENGINE),('2.3.16',CORE_2316_ENGINE),('2.3.17',CORE_2317_ENGINE),('2.3.21',CORE_2321_ENGINE),('2.3.22',CORE_2322_ENGINE),('2.3.25',CORE_2325_ENGINE),('2.3.27',CORE_2327_ENGINE),('2.3.29',CORE_2329_ENGINE),('2.3.31',CORE_2331_ENGINE),('2.3.34',CORE_2334_ENGINE)]:
        # JNI enables patch 0042 only above height 1330 and changes the line reference
        # to 1280x720 there. Neither that feedback path nor scaled lines is modeled.
        if (all(engine.get(key)==value for key,value in expected.items()) and
                (domain['height']>1330 or domain['width']*domain['height']>1024*768) and detail_context is None):
            raise ValueError(version+' higher-resolution lines/native feedback detail are not implemented')
    from quad_lines import PROFILE as quad_profile
    from field_math import SEPARATE_ARITHMETIC as separate_shader,APPLE_MIX_FMA
    shader_arithmetic_profile=domain.get('shader_arithmetic_profile',separate_shader)
    if shader_arithmetic_profile not in (separate_shader,APPLE_MIX_FMA):
        raise ValueError('unsupported shader arithmetic profile')
    if shader_arithmetic_profile==APPLE_MIX_FMA and (domain['profile']!='gles300' or not matches(engine,CORE_2317_ENGINE)):
        raise ValueError('mix FMA requires declared GLES300 and pinned2.3.17engine')
    from blur import SEPARATE_ARITHMETIC,ARITHMETIC_PROFILES,APPLE_FORWARD_FMA
    blur_arithmetic_profile=domain.get('blur_arithmetic_profile',SEPARATE_ARITHMETIC)
    if blur_arithmetic_profile not in ARITHMETIC_PROFILES:
        raise ValueError('unsupported blur arithmetic profile')
    qualified_blur=(matches(engine,CORE_2317_ENGINE) or
                    (matches(engine,CORE_2322_ENGINE) or (matches(engine,CORE_2325_ENGINE) or (matches(engine,CORE_2327_ENGINE) or (matches(engine,CORE_2329_ENGINE) or math_matches(engine,CORE_2331_ENGINE))))) and blur_arithmetic_profile==APPLE_FORWARD_FMA)
    if blur_arithmetic_profile!=SEPARATE_ARITHMETIC and (domain['profile']!='gles300' or not qualified_blur):
        raise ValueError('blur FMA requires declared GLES300 and a qualified engine context')
    from spatial import LEGACY_ROTATION,CPU_ROTATION,rotation_producer,zoom_power_producer
    current_rotation=matches(engine,CORE_2317_ENGINE) or (matches(engine,CORE_2327_ENGINE) or (matches(engine,CORE_2329_ENGINE) or math_matches(engine,CORE_2331_ENGINE)))
    rotation_policy=domain.get('warp_rotation_policy',CPU_ROTATION if current_rotation else LEGACY_ROTATION)
    if rotation_policy not in (LEGACY_ROTATION,CPU_ROTATION):raise ValueError('unknown warp rotation policy')
    if rotation_policy==CPU_ROTATION and not current_rotation:
        raise ValueError('CPU rotation engine identity mismatch')
    from motion_vectors import PORTABLE_STORAGE,APPLE_RTZ_STORAGE,APPLE_FINITE_STORAGE
    from motion_vectors import PORTABLE_SAMPLING, MEASURED_SAMPLING, validate_motion_sampler
    from measured_motion import MeasuredMotionSampler
    motion_sampling_profile=domain.get('motion_uv_sampling_profile',PORTABLE_SAMPLING)
    if motion_sampling_profile==MEASURED_SAMPLING:
        if (domain['profile']!='gles300' or not matches(engine,CORE_2317_ENGINE) or
                not isinstance(motion_uv_sampler,MeasuredMotionSampler) or
                domain.get('motion_uv_storage_profile')!=APPLE_FINITE_STORAGE):
            raise ValueError('measured motion sampling requires declared GLES300, pinned2.3.17, finite-half storage and explicit backend')
        if domain.get('motion_uv_operator_identity')!=motion_uv_sampler.identity:
            raise ValueError('measured motion operator identity must match frozen domain')
    validate_motion_sampler(motion_sampling_profile,motion_uv_sampler)
    motion_storage_profile=domain.get('motion_uv_storage_profile',PORTABLE_STORAGE)
    if motion_storage_profile not in (PORTABLE_STORAGE,APPLE_RTZ_STORAGE,APPLE_FINITE_STORAGE):
        raise ValueError('unknown motion UV storage profile')
    qualified_float_engine=any(math_matches(engine,target) for target in (CORE_2316_ENGINE,CORE_2317_ENGINE,CORE_2325_ENGINE,CORE_2327_ENGINE,CORE_2329_ENGINE,CORE_2331_ENGINE))
    if motion_storage_profile!=PORTABLE_STORAGE and (domain['profile']!='gles300' or not qualified_float_engine):
        raise ValueError('half motion storage requires declared GLES300 and a qualified engine context')
    composite_centre_policy,shape_centre_policy=source_centre_policies(engine,domain)
    line_profile=domain.get('line_rendering_profile','canonical-gl-lines-v1')
    builtin_wave_viewport_policy=source_builtin_viewport_policy(engine,domain)
    if line_profile not in {'canonical-gl-lines-v1',quad_profile}:
        raise ValueError('unknown line rendering profile')
    if line_profile==quad_profile:
        if domain['profile']!='gles300' or (domain['width']*domain['height']>1024*768 and detail_context is None):
            raise ValueError('quad-line profile requires GLES within reference area')
        if not any(all(engine.get(key)==value for key,value in expected.items())
                       for expected in PRODUCTION_EQUATION_ENGINES.values()):
                raise ValueError('quad-line engine identity mismatch')
    smoothing_profile=domain.get('custom_wave_smoothing_profile',DEFAULT_SMOOTHING)
    if smoothing_profile not in (DEFAULT_SMOOTHING,FMA_SMOOTHING):
        raise ValueError('unknown custom-wave smoothing profile')
    if smoothing_profile==FMA_SMOOTHING and (domain['profile']!='gles300' or not (qualified_float_engine or matches(engine,CORE_2322_ENGINE) or (matches(engine,CORE_2325_ENGINE) or (matches(engine,CORE_2327_ENGINE) or (matches(engine,CORE_2329_ENGINE) or math_matches(engine,CORE_2331_ENGINE)))))):
        raise ValueError('fused custom-wave smoothing requires declared GLES and a qualified engine context')
    colour = np.asarray(domain['initial_rgba'], dtype=np.float32)
    hue = np.asarray(domain['hue_offsets'], dtype=np.float32)
    if colour.shape!=(4,) or not np.all(np.isfinite(colour)) or np.any((colour<0)|(colour>1)):
        raise ValueError('explicit finite UNORM initial RGBA colour required')
    if hue.shape!=(4,) or not np.all(np.isfinite(hue)):
        raise ValueError('four finite source hue offsets required')
    if audio.get('uses_rendered_reference') is not False or not audio.get('frames'):
        raise ValueError('source-generated nonempty audio inputs required')
    archive = source.get('parser_inputs',{}).get('engine_archive_sha256')
    if not archive or audio.get('engine_archive_sha256')!=archive:
        raise ValueError('source/audio engine identity mismatch')
    reader = Path(binaries)/'milk-native-reader'
    reader_sha = hashlib.sha256(reader.read_bytes()).hexdigest()
    if source.get('reader_sha256')!=reader_sha:
        raise ValueError('source parser binary identity mismatch')
    width, height = domain['width'], domain['height']
    shader_numeric_policy=domain.get('shader_numeric_policy','strict')
    texture_sampling_profile=domain.get('texture_sampling_profile','portable')
    from unorm_sampler import sampler_2d
    sample_texture_2d=sample2d if texture_sampling_profile=='portable' else sampler_2d(texture_sampling_profile)
    if texture_sampling_profile!='portable' and domain['profile']!='gles300':
        raise ValueError('observed texture profile requires declared GLES300 context')
    if shader_numeric_policy!='strict' and domain['profile']!='gles300':
        raise ValueError('highp shader numeric policy requires GLES300')
    initial = np.broadcast_to(colour,(height,width,4)).copy()
    warp_code = source.get('sections',{}).get('warp_',{}).get('source','')
    # Native MilkdropPreset uses this literal substring test, including comments.
    warp_reads_blur = 'blur' in warp_code.lower()
    pipeline_arguments=dict(
        equation_loader_policy=domain.get('equation_loader_policy','strict-raw-v1'),
        main_binding_policy=main_binding_policy,
        blur_range_policy=blur_range_policy,legacy_control_policy=legacy_control_policy,
        initial_feedback=initial, warp_reads_blur=warp_reads_blur, blur_levels=domain['blur_levels'],
        quantize=domain['quantize'],coordinate_profile=domain.get('coordinate_profile','strict'),
        composite_subpixel_bits=domain.get('composite_subpixel_bits'),
        main_sampling_profile=domain.get('main_sampling_profile','portable'),shader_numeric_policy=shader_numeric_policy,
        texture_sampling_profile=texture_sampling_profile,line_rendering_profile=line_profile,
        motion_raster_subpixel_bits=domain.get('triangle_subpixel_bits'),
        motion_uv_storage_profile=motion_storage_profile,blur_arithmetic_profile=blur_arithmetic_profile,
        shader_arithmetic_profile=shader_arithmetic_profile,
        motion_uv_sampling_profile=motion_sampling_profile,motion_uv_sampler=motion_uv_sampler,
        composite_centre_policy=composite_centre_policy,
        shader_canvas_size=None if detail_context is None else detail_context['authored_size'],
        line_reference_size=None if detail_context is None else detail_context['authored_size'])
    for key in ('motion_map_policy','motion_uv_backend','shader_work_policy','shader_lowering_policy'):
        if key in domain:pipeline_arguments[key]=domain[key]
    pipeline=SourcePipeline.from_source(source,profile=domain['profile'],compatibility=compatibility,**pipeline_arguments)
    actual_legacy=math_matches(engine,CORE_2331_ENGINE) and pipeline.warp_tree is None
    legacy_warp_policy=domain.get('legacy_warp_policy',CORE_2331_LEGACY_WARP if actual_legacy else LEGACY_WARP)
    if legacy_warp_policy not in {LEGACY_WARP,CORE_2331_LEGACY_WARP}:
        raise ValueError('unsupported legacy warp policy')
    if legacy_warp_policy==CORE_2331_LEGACY_WARP and not actual_legacy:
        raise ValueError('legacy warp policy requires exact engine and actual default/fallback path')
    authored_pipeline=None;detail_pipeline=None
    scene_width,scene_height=width,height
    if detail_context is not None:
        from detail_pipeline import DetailPipeline
        scene_width,scene_height=detail_context['authored_size']
        low_arguments={**pipeline_arguments,
            'initial_feedback':np.broadcast_to(colour,(scene_height,scene_width,4)).copy(),
            'line_rendering_profile':'canonical-gl-lines-v1','line_reference_size':(0,0)}
        authored_pipeline=SourcePipeline.from_source(source,profile=domain['profile'],compatibility=compatibility,**low_arguments)
        detail_pipeline=DetailPipeline(authored_pipeline,pipeline,alpha=detail_context['alpha'])
    required_blur_level=native_blur_level(source,pipeline.stage_resolution)
    if shape_sampler_policy in {CORE_238_SHAPE_POLICY,CORE_2315_SHAPE} and domain['blur_levels']<required_blur_level:
        raise ValueError('declared blur levels omit native required resources')
    if materials is not None and noise_bank is not None:
        if materials.noise_bank is None or digest(material_input_identity(materials.noise_bank))!=digest(material_input_identity(noise_bank)):
            raise ValueError('combine procedural noise into the declared material bank')
    texture_bank=materials if materials is not None else noise_bank
    material_identity=material_input_identity(texture_bank)
    material_sha=None if material_identity is None else digest(material_identity)
    procedural=noise_bank if materials is None else materials.noise_bank
    if procedural is not None:
        from noise_inputs import validate_noise_clock
        validate_noise_clock(procedural,domain.get('declared_random_profile'),profile=domain['profile'])
        expected_upload = 'RGBA' if domain['profile']=='gles300' else 'BGRA'
        if procedural.upload_format!=expected_upload:
            raise ValueError('procedural material upload profile mismatch')
    material_uniforms={} if texture_bank is None else texture_bank.uniforms()
    def sample_external(detail,coordinates):
        if texture_sampling_profile=='portable':return texture_bank.sample(detail,coordinates)
        return texture_bank.sample(detail,coordinates,sampling_profile=texture_sampling_profile)
    # Lookup names are case-insensitive; generated uniform identifiers retain
    # their original spelling and sampler qualifiers.
    if texture_bank is not None:
        for prefix in ('warp_','comp_'):
            section=source.get('sections',{}).get(prefix,{})
            for node in section.get('tree',[]) or []:
                if node.get('kind')!='declarations':continue
                for declaration in node['values']:
                    name=declaration['name']
                    if not name.startswith('texsize_'):continue
                    texture=texture_settings(name.removeprefix('texsize_'))['texture'].lower()
                    if texture not in texture_bank.textures:continue
                    field=texture_bank.textures[texture]
                    h,w=field.shape[-3:-1]
                    material_uniforms[name]=[w,h,1/w,1/h]
    scene = execute_scene(source,audio['frames'],reader=reader,expected_reader_sha256=reader_sha,width=scene_width,height=scene_height,
        mesh_x=domain['mesh_x'],mesh_y=domain['mesh_y'],seed=domain['equation_seed'],
        timeout_seconds=domain.get('equation_timeout_seconds',60),
        equation_loader_policy=domain.get('equation_loader_policy','strict-raw-v1'),
        initial_shader_canvas=None if detail_context is None else detail_context['initial_shader_canvas'],
        legacy_warp_policy=legacy_warp_policy)
    geometry_features = scene_geometry_features(scene,
        max_derivative_samples=domain.get('geometry_derivative_sample_budget',1_000_000))
    builtin = source_builtin_wave(source,scene,audio,binary=Path(binaries)/'milk-wave-inputs',
                                  line_rendering_profile=line_profile if detail_context is None else 'canonical-gl-lines-v1',control_policy=wave_control_policy)
    if builtin['engine_archive_sha256']!=archive:
        raise ValueError('builtin-wave source engine identity mismatch')
    custom = source_custom_waves(source,scene,smoothing_profile=smoothing_profile)
    if random_inputs is not None:
        if random_inputs.get('ledger',{}).get('rendered_frames_consumed') is not False:
            raise ValueError('source-generated random input ledger required')
        if len(random_inputs.get('bindings',[]))!=len(scene['frames']):
            raise ValueError('random bindings must cover the exact frame schedule')
    frames = []
    for index, frame in enumerate(scene['frames']):
        main = frame['main']
        render_time=audio['frames'][index]['time']
        unused_warp_uv_domain=None
        try:
            mesh = warp_fields(source,scene,index,numeric_profile=domain.get('numeric_profile','portable'),
                               raster_subpixel_bits=domain.get('warp_subpixel_bits'),zoom_policy=warp_zoom_policy,rotation_policy=rotation_policy)
        except ValueError as error:
            if str(error) not in {'unresolved warp numeric domain','unresolved warp power domain','zero spatial divisor'}:raise
            consumed_pipeline=pipeline if authored_pipeline is None else authored_pipeline
            if consumed_pipeline.requires_warp_uv(frame_wrap=main['wrap'],motion_state=main):raise
            unused_warp_uv_domain=str(error)
            mesh=warp_fields(source,scene,index,raster_subpixel_bits=domain.get('warp_subpixel_bits'),
                             omit_transformed_uv=True,zoom_policy=warp_zoom_policy,rotation_policy=rotation_policy)
        native_mesh=mesh
        if detail_context is not None:
            native_mesh=warp_fields(source,scene,index,output_size=(width,height),
                raster_subpixel_bits=domain.get('warp_subpixel_bits'),
                omit_transformed_uv=detail_context['alpha']==0 or mesh['uv'] is None,
                numeric_profile=domain.get('numeric_profile','portable'),
                zoom_policy=warp_zoom_policy,rotation_policy=rotation_policy)
        common = source_uniforms(scene,index)
        if texture_bank is not None:
            common.update(material_uniforms)
        random_banks = {}
        if random_inputs is not None:
            bindings = random_inputs['bindings'][index]
            if set(bindings)-{'warp','composite'}:
                raise ValueError('random binding stage must be warp/composite')
            for stage, binding in bindings.items():
                cache_context = ({'frame':int(frame['render_inputs']['frame']),
                                  'feedback_detail_alpha':-1.0 if detail_context is None else detail_context['alpha']}
                                 if 'frame_cache_policy' in random_inputs['ledger'] else {})
                random_banks[stage] = bind_random_uniforms(random_inputs['ledger'],
                    event_index=binding['event_index'],shader_id=binding['shader_id'],
                    time=render_time,profile=random_inputs['profile'],**cache_context)

        def draw(destination, frame_index, previous_main):
            reference=None
            draw_profile=line_profile
            if detail_context is not None:
                native_target=destination.shape[:2]==(height,width)
                reference=detail_context['authored_size'] if native_target else (0,0)
                if not native_target:draw_profile='canonical-gl-lines-v1'
            textures = {}; texture_aspects = {}
            images={shape['index']:source['values'].get(f"shapecode_{shape['index']}_image",'') for shape in frame['shapes']}
            modes=shape_sampling_modes(frame['shapes'],image_names=images,policy=shape_sampler_policy,
                                       warp_reads_blur=warp_reads_blur,blur_level=required_blur_level,frame_wrap=main['wrap'])
            for ordinal,shape in enumerate(frame['shapes']):
                if not int(shape['values'].get('textured',0)):
                    continue
                shape_index = shape['index']
                binding_key=(shape_index,ordinal)
                image = source['values'].get(f'shapecode_{shape_index}_image','')
                if image:
                    # Named-image loading/missing-image fallback needs a bound
                    # material registry; do not pretend an unknown image is main.
                    policy=texture_settings(image);name=policy['texture'].lower()
                    if texture_bank is None or name not in texture_bank.textures:
                        raise ValueError('source shape image binding unresolved: ' + image)
                    if texture_bank.textures[name].ndim!=3:
                        raise ValueError('source shape image must be a two-dimensional texture')
                    detail={'canonical_texture':name,'sampling_policy':{'wrap':policy['wrap'],'linear':policy['linear']}}
                    textures[binding_key]=lambda uv, detail=detail:sample_external(detail,uv)
                    texture_aspects[shape_index]=1
                else:
                    textures[binding_key]=lambda uv, mode=modes[ordinal]:sample_texture_2d(previous_main,uv,wrap=mode['wrap'],linear=mode['linear'],origin='top')
            return draw_source_scene(destination,source,frame,builtin['frames'][index],custom['frames'][index],
                quantize=domain['quantize'],shape_textures=textures,shape_texture_aspects=texture_aspects,
                motion_vectors_prewarped=True,line_rendering_profile=draw_profile,
                point_subpixel_bits=domain.get('point_subpixel_bits'),
                triangle_subpixel_bits=domain.get('triangle_subpixel_bits'),shape_centre_policy=shape_centre_policy,
                builtin_wave_viewport_policy=builtin_wave_viewport_policy,line_reference_size=reference)

        step_arguments=dict(uniforms=common,
            frame_wrap=main['wrap'],stage_uniforms=random_banks,decay=main['decay'],
            minimum=[main[f'blur{i}_min'] for i in range(1,4)],
            maximum=[main[f'blur{i}_max'] for i in range(1,4)],edge_darken=main['blur1_edge_darken'],
            motion_state=main,render_time=render_time,
            hue_offsets=hue.tolist(),external_sample=None if texture_bank is None else sample_external)
        if detail_pipeline is None:
            result=pipeline.step(warp_uv=mesh['original_uv'] if mesh['uv'] is None else mesh['uv'],
                warp_original_uv=mesh['original_uv'],warp_polar=mesh['polar'],draw_scene=draw,**step_arguments)
        else:
            result=detail_pipeline.step(
                authored_warp_uv=mesh['original_uv'] if mesh['uv'] is None else mesh['uv'],
                native_warp_uv=native_mesh['original_uv'] if native_mesh['uv'] is None else native_mesh['uv'],
                authored_original_uv=mesh['original_uv'],native_original_uv=native_mesh['original_uv'],
                authored_polar=mesh['polar'],native_polar=native_mesh['polar'],
                draw_authored=draw,draw_native=draw,**step_arguments)
        display=result.display
        if detail_context is not None and detail_context['physical_size']!=(width,height):
            from authored_canvas import _upsample
            from feedback_field import unorm8
            display=unorm8(_upsample(display,*detail_context['physical_size'],texture_sampling_profile))
            result.history['physical_surface_size']=list(detail_context['physical_size'])
        predicted = dict(frame=frame['render_inputs']['frame'],time=render_time,
                         display=display,feedback=result.feedback,warp_uv=native_mesh['uv'],history=result.history,
                         visibility=display_visibility(display))
        if unused_warp_uv_domain is not None:
            predicted['history']['unused_warp_uv_domain']=unused_warp_uv_domain
        descriptors.add(predicted)
        if on_frame is not None:
            on_frame(copy.deepcopy(predicted))
        frames.append(predicted if retain_surfaces else
                      {key:value for key,value in predicted.items() if key not in {'display','feedback','warp_uv'}})
    if model_file_hashes()!=model_hashes:
        raise ValueError('forecast model files changed during evaluation')
    if material_input_identity(texture_bank)!=material_identity:
        raise ValueError('forecast sampled material inputs changed during evaluation')
    report = dict(status='computed',frames=frames,domain=domain,stage_resolution=pipeline.stage_resolution,
        feature_basis=SIMULATED,geometry_features=geometry_features,
        visibility_frames=[dict(frame=frame['frame'],time=frame['time'],**frame['visibility']) for frame in frames],
        source_proofs=dict(basis='source-equation-write-analysis',
            untouched_main_q_components=copy.deepcopy(pipeline.known_uniform_components),
            scope='Proven untouched components under the declared equation loader; absent components are not proven constant',
            effect_rule='A texture read does not establish an active visual effect; check coefficients, branches and storage clipping'),
        source_equation_states=dict(basis='sampled-source-equation-execution',
            storage='Native EEL main values before shader float32 packing',
            scope='Only the declared sampled frames; not a whole-program or shader-branch activation proof',
            states=[dict(frame=frame['render_inputs']['frame'],eel_frame=frame['main']['frame'],time=frame['render_inputs']['time'],
                q={f'q{i}':copy.deepcopy(frame['main'][f'q{i}']) for i in range(1,33)},
                custom=copy.deepcopy(frame['main_custom'])) for frame in scene['frames']]),
        descriptors=descriptors.report(),
        uses_rendered_reference=False,appearance_accuracy_verified=False,
        input_hashes=dict(preset_sha256=source['preset_sha256'],pcm_sha256=audio['pcm_sha256'],
                          parsed_source_sha256=digest({key:source[key] for key in ['values','sections','parser_inputs']}),
                          domain_sha256=digest(domain),audio_sha256=digest(audio),
                          compatibility_sha256=digest(compatibility),
                          random_sha256=None if random_inputs is None else digest(random_inputs),
                          materials_sha256=material_sha),
        provenance=dict(engine=copy.deepcopy(engine),composite_centre_policy=composite_centre_policy,
                        shape_centre_policy=shape_centre_policy,reader_sha256=reader_sha,wave_binary_sha256=builtin['native_binary_sha256'],
                        material_input_policy=None if material_identity is None else material_identity['policy'],
                        shader_numeric_policy=shader_numeric_policy,
                        shader_arithmetic_profile=shader_arithmetic_profile,
                        main_binding_policy=main_binding_policy,
                        shape_sampler_policy=shape_sampler_policy,native_required_blur_level=required_blur_level,
                        blur_range_policy=blur_range_policy,warp_zoom_policy=warp_zoom_policy,
                        warp_zoom_power_producer=zoom_power_producer(warp_zoom_policy),
                        blur_arithmetic_profile=blur_arithmetic_profile,
                        warp_rotation_policy=rotation_policy,
                        warp_rotation_producer=rotation_producer(rotation_policy),
                        legacy_control_policy=legacy_control_policy,wave_control_policy=wave_control_policy,
                        legacy_warp_policy=legacy_warp_policy,
                        builtin_wave_appearance_policy=builtin['appearance_policy'],
                        custom_wave_dot_policy=custom['dot_submission_policy'],
                        legacy_tint_amount=None if pipeline.legacy_tint_amount is None else float(pipeline.legacy_tint_amount),
                        mode1_alpha_boost=(matches(engine,CORE_2325_ENGINE) or (matches(engine,CORE_2327_ENGINE) or (matches(engine,CORE_2329_ENGINE) or math_matches(engine,CORE_2331_ENGINE)))),
                        builtin_wave_viewport_policy=builtin_wave_viewport_policy,
                        render_context_source_sha256=builtin['render_context_source_sha256'],
                        render_context_time_bits=builtin['render_context_time_bits'],
                        engine_archive_sha256=archive,model_sha256=digest(model_hashes),model_modules=model_hashes,
                        equation_rng=dict(policy=rng_policy,seed=domain['equation_seed'],
                            lifecycle='fresh evaluator thread; no previous equation draws',
                            native_sequence_verified=False)),
        limitations=['GPU rasterization, sampling and arithmetic precision not validated',
                     'Target shader compilation/linking and fallback remain profile conditions',
                     'Initial state and RNG/resource lifecycle are declared inputs, not inferred engine startup'])
    report['provenance']['authored_detail_context']=copy.deepcopy(detail_context)
    report['provenance']['motion_uv_sampling_profile']=motion_sampling_profile
    report['provenance']['motion_map_policy']=pipeline.motion_map_policy
    report['provenance']['motion_uv_backend']=pipeline.motion_uv_backend
    report['provenance']['shader_work_policy']=pipeline.shader_work_policy
    report['provenance']['shader_lowering_policy']=pipeline.shader_lowering_policy
    report['prediction_basis']='independent-source-math'
    if motion_uv_sampler is not None:
        report['prediction_basis']='source-with-measured-operator'
        report['provenance']['motion_uv_operator']=motion_uv_sampler.report()
        report['limitations'].append('Half motion filtering uses a declared numerical GPU operator; independent hardware arithmetic is not reconstructed')
    report['source_features'] = forecast_feature_record(report)
    return report
